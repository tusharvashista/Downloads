package petcare;

public enum AnimalSize {
    SMALL, MEDIUM, LARGE;
}
