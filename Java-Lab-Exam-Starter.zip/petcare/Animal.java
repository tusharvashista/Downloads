package petcare;

public class Animal {
    // Write your implementation here
}
